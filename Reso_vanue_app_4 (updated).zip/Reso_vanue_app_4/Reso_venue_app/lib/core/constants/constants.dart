class Constants {
  static const APP_VERSION = 0;
}