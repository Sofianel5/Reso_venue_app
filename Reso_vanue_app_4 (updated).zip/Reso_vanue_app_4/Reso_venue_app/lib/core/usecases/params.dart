import 'package:equatable/equatable.dart';

class Params extends Equatable {
  Params();
  @override
  List<Object> get props => [];
}
class NoParams extends Params {}