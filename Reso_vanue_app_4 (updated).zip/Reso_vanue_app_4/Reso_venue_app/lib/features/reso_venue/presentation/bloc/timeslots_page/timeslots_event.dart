part of '../root_bloc.dart';

class TimeSlotEvent extends HomeEvent {}

class TimeSlotCreation extends TimeSlotEvent {}

class TimeSlotsRequestHistory extends TimeSlotEvent {}

class TimeSlotsRequestCurrent extends TimeSlotEvent {}
