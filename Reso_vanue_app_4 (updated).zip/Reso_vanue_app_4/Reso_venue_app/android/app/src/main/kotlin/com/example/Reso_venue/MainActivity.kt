package com.example.Reso_venue

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
